import { StatsGrid } from "@/components/StatsGrid";
import { SignalsList } from "@/components/SignalsList";
import { CreateSignalDialog } from "@/components/CreateSignalDialog";
import { Terminal, Activity, BrainCircuit } from "lucide-react";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden pb-20">
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-[hsl(var(--trade-up))]/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 md:pt-12 relative z-10">
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-primary/10 rounded-xl border border-primary/20">
                <Terminal className="w-6 h-6 text-primary" />
              </div>
              <h1 className="text-3xl md:text-4xl font-display font-bold text-gradient">
                QuantumTrade AI
              </h1>
            </div>
            <p className="text-muted-foreground max-w-xl text-sm md:text-base">
              Fetches live Yahoo Finance data → calculates RSI, MACD, Bollinger Bands, EMA crossovers → generates Pocket Option binary signals. Mark WIN/LOSS to train the model.
            </p>
          </div>
          <div className="shrink-0">
            <CreateSignalDialog />
          </div>
        </header>

        {/* Stats + Indicator Weights */}
        <StatsGrid />

        {/* Signal Feed */}
        <div className="space-y-6">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <h2 className="text-xl font-display font-semibold flex items-center gap-2 text-foreground">
              <Activity className="w-5 h-5 text-primary" />
              Live Signal Feed
            </h2>
            <div className="flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
              </span>
              <span className="text-sm font-mono text-muted-foreground uppercase tracking-wider">Real Market Data</span>
            </div>
          </div>

          <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 flex gap-2 text-sm text-muted-foreground">
            <BrainCircuit className="w-4 h-4 text-primary shrink-0 mt-0.5" />
            <span>
              <strong className="text-primary">How learning works:</strong> Each signal stores which indicators voted BUY/SELL. When you mark WIN/LOSS, the engine adjusts indicator weights — correct indicators gain weight, wrong ones lose it. Accuracy improves over time.
            </span>
          </div>

          <SignalsList />
        </div>
      </div>
    </div>
  );
}
