import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useSignals() {
  return useQuery({
    queryKey: [api.signals.list.path],
    queryFn: async () => {
      const res = await fetch(api.signals.list.path);
      if (!res.ok) throw new Error('Failed to fetch signals');
      return res.json();
    },
  });
}

export function useStats() {
  return useQuery({
    queryKey: [api.signals.stats.path],
    queryFn: async () => {
      const res = await fetch(api.signals.stats.path);
      if (!res.ok) throw new Error('Failed to fetch stats');
      return res.json();
    },
    refetchInterval: 15000,
  });
}

export function useAssets() {
  return useQuery<string[]>({
    queryKey: ['/api/assets'],
    queryFn: async () => {
      const res = await fetch('/api/assets');
      if (!res.ok) throw new Error('Failed to fetch assets');
      return res.json();
    },
  });
}

export function useGenerateSignal() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { asset: string; timeframe: string }) => {
      const res = await fetch(api.signals.generate.path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to generate signal');
      }
      return res.json();
    },
    onSuccess: (signal) => {
      queryClient.invalidateQueries({ queryKey: [api.signals.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.signals.stats.path] });
      toast({
        title: `Signal Generated: ${signal.action}`,
        description: `${signal.asset} — Confidence ${signal.confidence}%`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

export function useUpdateSignalResult() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, result }: { id: number; result: 'WIN' | 'LOSS' }) => {
      const url = buildUrl(api.signals.updateResult.path, { id });
      const res = await fetch(url, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ result }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to update signal');
      }
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.signals.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.signals.stats.path] });
      toast({
        title: "Model Updated",
        description: `Signal marked ${variables.result}. Indicator weights adjusted.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}
