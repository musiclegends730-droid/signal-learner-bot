import { useState } from "react";
import { useGenerateSignal, useAssets } from "@/hooks/use-signals";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Zap, BrainCircuit, AlertCircle, Loader2 } from "lucide-react";

const TIMEFRAMES = [
  { value: '1m', label: '1 Minute' },
  { value: '5m', label: '5 Minutes' },
  { value: '15m', label: '15 Minutes' },
  { value: '1h', label: '1 Hour' },
];

export function CreateSignalDialog() {
  const [open, setOpen] = useState(false);
  const [asset, setAsset] = useState("EUR/USD");
  const [timeframe, setTimeframe] = useState("5m");

  const generateMutation = useGenerateSignal();
  const { data: assets, isLoading: assetsLoading } = useAssets();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    generateMutation.mutate(
      { asset, timeframe },
      {
        onSuccess: () => {
          setOpen(false);
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          data-testid="button-generate-signal"
          className="relative group overflow-hidden bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-6 py-5 rounded-xl shadow-[0_0_20px_hsla(var(--primary)/0.3)] transition-all hover:shadow-[0_0_30px_hsla(var(--primary)/0.5)] hover:-translate-y-0.5"
        >
          <Zap className="w-5 h-5 mr-2 fill-current" />
          Scan Market & Generate Signal
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-[420px] glass-panel border-white/10">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display flex items-center gap-2">
            <BrainCircuit className="w-6 h-6 text-primary" />
            Auto-Scan Signal
          </DialogTitle>
          <DialogDescription className="text-muted-foreground text-sm">
            The bot will fetch live market data, calculate RSI, MACD, Bollinger Bands, and EMA crossovers, then generate a BUY or SELL signal.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5 mt-2">
          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Asset Pair</Label>
            <Select value={asset} onValueChange={setAsset}>
              <SelectTrigger data-testid="select-asset" className="h-12 font-mono text-base bg-black/40 border-white/10">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-card border-white/10">
                {assetsLoading ? (
                  <SelectItem value="EUR/USD">EUR/USD</SelectItem>
                ) : (
                  assets?.map(a => (
                    <SelectItem key={a} value={a} className="font-mono">{a}</SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Analysis Timeframe</Label>
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger data-testid="select-timeframe" className="h-12 bg-black/40 border-white/10">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-card border-white/10">
                {TIMEFRAMES.map(t => (
                  <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 flex gap-2 text-sm text-muted-foreground">
            <AlertCircle className="w-4 h-4 text-primary shrink-0 mt-0.5" />
            <span>Live price data is fetched from Yahoo Finance. Market must be open for real-time accuracy.</span>
          </div>

          <Button
            type="submit"
            data-testid="button-run-scan"
            disabled={generateMutation.isPending}
            className="w-full h-12 text-base font-bold"
          >
            {generateMutation.isPending ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Fetching Live Data & Analyzing...
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 mr-2 fill-current" />
                Run Analysis
              </>
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
