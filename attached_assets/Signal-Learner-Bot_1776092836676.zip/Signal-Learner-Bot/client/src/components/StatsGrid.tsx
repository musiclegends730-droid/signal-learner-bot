import { useStats } from "@/hooks/use-signals";
import { Card } from "@/components/ui/card";
import { BrainCircuit, Activity, TrendingUp, Target } from "lucide-react";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";
import type { IndicatorWeight } from "@shared/schema";

const INDICATOR_LABELS: Record<string, string> = {
  rsi:           'RSI (14)',
  macd:          'MACD (12,26,9)',
  bollingerBands:'Bollinger Bands',
  emaCross:      'EMA Cross (9,21)',
  stochastic:    'Stochastic (14,3)',
  priceAction:   'Price Action',
};

function WeightBar({ weight, name }: { weight: IndicatorWeight; name: string }) {
  const w = parseFloat(weight.weight as string);
  const pct = Math.min(100, (w / 2.5) * 100);
  const label = INDICATOR_LABELS[weight.name] || weight.name;
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-mono text-foreground">{w.toFixed(2)}</span>
      </div>
      <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
        <div
          className="h-full bg-primary transition-all duration-700 rounded-full"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export function StatsGrid() {
  const { data: stats, isLoading } = useStats();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-32 rounded-xl bg-muted/50" />
        ))}
      </div>
    );
  }

  if (!stats) return null;

  const winRate = stats.winRate;
  const isGoodWinRate = winRate > 60;

  const cards = [
    {
      title: "Model Confidence",
      value: `${stats.currentConfidence}%`,
      subtitle: "Weighted avg based on win rate",
      icon: BrainCircuit,
      colorClass: "text-primary",
      bgClass: "bg-primary/10",
      borderClass: "border-primary/20",
    },
    {
      title: "Win Rate",
      value: `${winRate.toFixed(1)}%`,
      subtitle: "Based on resolved signals",
      icon: Target,
      colorClass: isGoodWinRate ? "text-[hsl(var(--trade-up))]" : "text-yellow-500",
      bgClass: isGoodWinRate ? "bg-[hsl(var(--trade-up))]/10" : "bg-yellow-500/10",
      borderClass: isGoodWinRate ? "border-[hsl(var(--trade-up))]/20" : "border-yellow-500/20",
    },
    {
      title: "Total Wins",
      value: stats.wins.toString(),
      subtitle: `${stats.losses} losses recorded`,
      icon: TrendingUp,
      colorClass: "text-[hsl(var(--trade-up))]",
      bgClass: "bg-[hsl(var(--trade-up))]/10",
      borderClass: "border-[hsl(var(--trade-up))]/20",
    },
    {
      title: "Total Signals",
      value: stats.totalSignals.toString(),
      subtitle: "All generated signals",
      icon: Activity,
      colorClass: "text-muted-foreground",
      bgClass: "bg-muted",
      borderClass: "border-border",
    },
  ];

  return (
    <div className="space-y-6 mb-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {cards.map((card, index) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
          >
            <Card className={`p-6 flex flex-col justify-between h-full glass-panel border ${card.borderClass} hover:bg-white/[0.02] transition-colors relative overflow-hidden group`}>
              <div className={`absolute -right-10 -top-10 w-32 h-32 blur-[50px] rounded-full ${card.bgClass} opacity-50 group-hover:opacity-100 transition-opacity`} />
              <div className="flex items-center justify-between mb-4 relative z-10">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{card.title}</h3>
                <div className={`p-2 rounded-lg ${card.bgClass}`}>
                  <card.icon className={`w-5 h-5 ${card.colorClass}`} />
                </div>
              </div>
              <div className="relative z-10">
                <div className="text-3xl font-bold font-mono tracking-tight text-foreground">
                  {card.value}
                </div>
                <p className="text-xs text-muted-foreground mt-1">{card.subtitle}</p>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Indicator Weights Panel */}
      {stats.indicatorWeights && stats.indicatorWeights.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.5 }}
        >
          <Card className="p-5 glass-panel border-border">
            <div className="flex items-center gap-2 mb-4">
              <BrainCircuit className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider">Learned Indicator Weights</h3>
              <span className="text-xs text-muted-foreground ml-auto">Updated after each WIN/LOSS</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {stats.indicatorWeights.map((w: IndicatorWeight) => (
                <WeightBar key={w.name} weight={w} name={w.name} />
              ))}
            </div>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
