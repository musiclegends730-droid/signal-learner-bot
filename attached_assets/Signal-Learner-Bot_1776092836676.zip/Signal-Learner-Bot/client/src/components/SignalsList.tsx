import { useSignals, useUpdateSignalResult } from "@/hooks/use-signals";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowUpRight, ArrowDownRight, CheckCircle2, XCircle, BrainCircuit,
  Clock, BarChart2, Activity, TrendingUp, ChevronDown, Waves
} from "lucide-react";
import type { Signal, IndicatorSnapshot } from "@shared/schema";

const INDICATOR_META: Record<string, { label: string; Icon: any }> = {
  rsi:           { label: 'RSI',         Icon: Activity },
  macd:          { label: 'MACD',        Icon: BarChart2 },
  bollingerBands:{ label: 'Bollinger',   Icon: Waves },
  emaCross:      { label: 'EMA Cross',   Icon: TrendingUp },
  stochastic:    { label: 'Stochastic',  Icon: BarChart2 },
  priceAction:   { label: 'Price Action',Icon: Activity },
};

function IndicatorBadge({ name, vote }: { name: string; vote: { direction: string; value: number; confidence: number } }) {
  const meta = INDICATOR_META[name] || { label: name, Icon: Activity };
  const isBuy = vote.direction === 'BUY';
  const isSell = vote.direction === 'SELL';
  const isNeutral = vote.direction === 'NEUTRAL';
  return (
    <div className={`flex items-center gap-1.5 rounded-md px-2 py-1 text-xs font-mono ${
      isBuy
        ? 'bg-[hsl(var(--trade-up))]/10 text-[hsl(var(--trade-up))] border border-[hsl(var(--trade-up))]/20'
        : isSell
        ? 'bg-[hsl(var(--trade-down))]/10 text-[hsl(var(--trade-down))] border border-[hsl(var(--trade-down))]/20'
        : 'bg-white/5 text-muted-foreground border border-white/5'
    }`}>
      <meta.Icon className="w-3 h-3" />
      <span>{meta.label}</span>
      <span className="font-bold">{isNeutral ? '—' : vote.direction}</span>
    </div>
  );
}

export function SignalsList() {
  const { data: signals, isLoading } = useSignals();
  const updateMutation = useUpdateSignalResult();

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-32 w-full rounded-xl bg-muted/50" />
        ))}
      </div>
    );
  }

  if (!signals || signals.length === 0) {
    return (
      <Card className="p-12 flex flex-col items-center justify-center text-center border-dashed border-2 glass-panel border-white/10">
        <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mb-4">
          <BrainCircuit className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-xl font-display font-bold text-foreground mb-2">No Signals Yet</h3>
        <p className="text-muted-foreground max-w-sm text-sm">
          Click "Scan Market & Generate Signal" above to fetch live market data and generate your first AI-powered binary options signal.
        </p>
      </Card>
    );
  }

  const sortedSignals = [...signals].sort((a: Signal, b: Signal) => {
    if (a.result === 'PENDING' && b.result !== 'PENDING') return -1;
    if (a.result !== 'PENDING' && b.result === 'PENDING') return 1;
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  const handleUpdate = (id: number, result: 'WIN' | 'LOSS') => {
    updateMutation.mutate({ id, result });
  };

  return (
    <div className="space-y-4">
      <AnimatePresence mode="popLayout">
        {sortedSignals.map((signal: Signal) => (
          <SignalRow
            key={signal.id}
            signal={signal}
            onUpdate={handleUpdate}
            isUpdating={updateMutation.isPending && (updateMutation.variables as any)?.id === signal.id}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}

function SignalRow({
  signal,
  onUpdate,
  isUpdating
}: {
  signal: Signal;
  onUpdate: (id: number, result: 'WIN' | 'LOSS') => void;
  isUpdating: boolean;
}) {
  const isBuy = signal.action === 'BUY';
  const isPending = signal.result === 'PENDING';
  const indicators = signal.indicators as IndicatorSnapshot | null;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98, transition: { duration: 0.2 } }}
      className={`relative group rounded-xl border transition-all duration-300 ${
        isPending
          ? 'bg-card border-white/10 shadow-lg'
          : 'bg-black/40 border-white/5 opacity-80 hover:opacity-100'
      }`}
    >
      <div className="p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          {/* Asset + Action */}
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-lg shrink-0 ${
              isBuy ? 'bg-[hsl(var(--trade-up))]/10 text-[hsl(var(--trade-up))]' : 'bg-[hsl(var(--trade-down))]/10 text-[hsl(var(--trade-down))]'
            }`}>
              {isBuy ? <ArrowUpRight className="w-6 h-6" /> : <ArrowDownRight className="w-6 h-6" />}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h4 data-testid={`text-asset-${signal.id}`} className="text-xl font-bold font-mono tracking-tight">{signal.asset}</h4>
                <Badge
                  variant="outline"
                  className={`font-mono font-bold border-transparent ${
                    isBuy
                      ? 'bg-[hsl(var(--trade-up))]/20 text-[hsl(var(--trade-up))]'
                      : 'bg-[hsl(var(--trade-down))]/20 text-[hsl(var(--trade-down))]'
                  }`}
                >
                  {signal.action}
                </Badge>
                {signal.timeframe && (
                  <Badge variant="outline" className="text-muted-foreground border-white/10 text-xs font-mono">
                    <Clock className="w-3 h-3 mr-1" />
                    {signal.timeframe}
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-3 text-sm text-muted-foreground font-mono">
                <span>Entry: <span className="text-foreground">{parseFloat(signal.price as string).toFixed(5)}</span></span>
                <span className="opacity-50">•</span>
                <span>{format(new Date(signal.createdAt), "HH:mm:ss")}</span>
              </div>
            </div>
          </div>

          {/* Confidence + Actions */}
          <div className="flex items-center justify-between sm:justify-end gap-6 sm:gap-8 w-full sm:w-auto">
            <div className="flex flex-col items-end">
              <span className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Confidence</span>
              <div className="flex items-center gap-2">
                <div className="w-16 h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all duration-1000"
                    style={{ width: `${signal.confidence}%` }}
                  />
                </div>
                <span data-testid={`text-confidence-${signal.id}`} className="font-mono text-sm font-medium">{signal.confidence}%</span>
              </div>
            </div>

            <div className="flex items-center gap-2 min-w-[140px] justify-end">
              {isPending ? (
                <>
                  <Button
                    data-testid={`button-win-${signal.id}`}
                    size="sm"
                    variant="outline"
                    className="bg-black/50 border-[hsl(var(--trade-up))]/30 text-[hsl(var(--trade-up))] hover:bg-[hsl(var(--trade-up))]/20 hover:border-[hsl(var(--trade-up))]"
                    onClick={() => onUpdate(signal.id, 'WIN')}
                    disabled={isUpdating}
                  >
                    WIN
                  </Button>
                  <Button
                    data-testid={`button-loss-${signal.id}`}
                    size="sm"
                    variant="outline"
                    className="bg-black/50 border-[hsl(var(--trade-down))]/30 text-[hsl(var(--trade-down))] hover:bg-[hsl(var(--trade-down))]/20 hover:border-[hsl(var(--trade-down))]"
                    onClick={() => onUpdate(signal.id, 'LOSS')}
                    disabled={isUpdating}
                  >
                    LOSS
                  </Button>
                </>
              ) : (
                <Badge
                  data-testid={`status-result-${signal.id}`}
                  className={`px-3 py-1.5 text-sm font-bold flex items-center gap-1.5 ${
                    signal.result === 'WIN'
                      ? 'bg-[hsl(var(--trade-up))]/20 text-[hsl(var(--trade-up))] border-[hsl(var(--trade-up))]/30'
                      : 'bg-[hsl(var(--trade-down))]/20 text-[hsl(var(--trade-down))] border-[hsl(var(--trade-down))]/30'
                  }`}
                  variant="outline"
                >
                  {signal.result === 'WIN' ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                  {signal.result}
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Indicator Breakdown */}
        {indicators && (
          <div className="mt-3 pt-3 border-t border-white/5 flex flex-wrap gap-2">
            {Object.entries(indicators).map(([name, vote]) => (
              <IndicatorBadge key={name} name={name} vote={vote as any} />
            ))}
          </div>
        )}
      </div>

      {isPending && (
        <div className="absolute -bottom-px left-4 right-4 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      )}
    </motion.div>
  );
}
