## Packages
framer-motion | Smooth animations for dashboard elements and list transitions
lucide-react | Icons for the trading dashboard

## Notes
The application is a single-page dashboard so most logic is in one main route.
Needs to use strict dark mode for the professional trading terminal aesthetic.
