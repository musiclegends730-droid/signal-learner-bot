import { db } from "./db";
import { signals, indicatorWeights, type Signal, type IndicatorWeight } from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { INDICATOR_NAMES, type WeightMap, getDefaultWeights } from "./mlEngine";

export interface IStorage {
  getSignals(): Promise<Signal[]>;
  getSignal(id: number): Promise<Signal | undefined>;
  createSignal(signal: Omit<Signal, 'id' | 'createdAt'>): Promise<Signal>;
  updateSignalResult(id: number, result: 'WIN' | 'LOSS'): Promise<Signal>;
  getStats(): Promise<{ totalSignals: number; wins: number; losses: number; winRate: number; currentConfidence: number; indicatorWeights: IndicatorWeight[] }>;
  getWeights(): Promise<WeightMap>;
  updateWeights(weights: WeightMap): Promise<void>;
  initWeightsIfNeeded(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getSignals(): Promise<Signal[]> {
    return await db.select().from(signals).orderBy(desc(signals.createdAt));
  }

  async getSignal(id: number): Promise<Signal | undefined> {
    const [signal] = await db.select().from(signals).where(eq(signals.id, id));
    return signal;
  }

  async createSignal(signal: Omit<Signal, 'id' | 'createdAt'>): Promise<Signal> {
    const [newSignal] = await db.insert(signals).values(signal as any).returning();
    return newSignal;
  }

  async updateSignalResult(id: number, result: 'WIN' | 'LOSS'): Promise<Signal> {
    const [updated] = await db.update(signals)
      .set({ result })
      .where(eq(signals.id, id))
      .returning();
    return updated;
  }

  async getStats(): Promise<{ totalSignals: number; wins: number; losses: number; winRate: number; currentConfidence: number; indicatorWeights: IndicatorWeight[] }> {
    const allSignals = await db.select().from(signals);
    const weights = await db.select().from(indicatorWeights);
    
    const totalSignals = allSignals.length;
    const wins = allSignals.filter(s => s.result === 'WIN').length;
    const losses = allSignals.filter(s => s.result === 'LOSS').length;
    const resolvedSignals = wins + losses;
    const winRate = resolvedSignals > 0 ? Math.round((wins / resolvedSignals) * 100) : 0;

    let currentConfidence = 75;
    if (resolvedSignals > 0) {
      currentConfidence = Math.min(99, Math.max(50, Math.round(50 + (winRate * 0.49))));
    }

    return { totalSignals, wins, losses, winRate, currentConfidence, indicatorWeights: weights };
  }

  async getWeights(): Promise<WeightMap> {
    await this.initWeightsIfNeeded();
    const rows = await db.select().from(indicatorWeights);
    const defaults = getDefaultWeights();
    const result = { ...defaults };
    for (const row of rows) {
      if (INDICATOR_NAMES.includes(row.name as any)) {
        result[row.name as keyof WeightMap] = parseFloat(row.weight as string);
      }
    }
    return result;
  }

  async updateWeights(weights: WeightMap): Promise<void> {
    for (const name of INDICATOR_NAMES) {
      await db.update(indicatorWeights)
        .set({ weight: weights[name].toString(), updatedAt: new Date() })
        .where(eq(indicatorWeights.name, name));
    }
  }

  async initWeightsIfNeeded(): Promise<void> {
    const existing = await db.select().from(indicatorWeights);
    const existingNames = new Set(existing.map(r => r.name));
    for (const name of INDICATOR_NAMES) {
      if (!existingNames.has(name)) {
        await db.insert(indicatorWeights).values({
          name,
          weight: '1.0',
          correctPredictions: 0,
          totalPredictions: 0,
        });
      }
    }
  }
}

export const storage = new DatabaseStorage();
