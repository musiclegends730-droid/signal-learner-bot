import YahooFinance from 'yahoo-finance2';
import type { MarketCandle } from '@shared/schema';

const yahooFinance = new YahooFinance();

// Map Pocket Option asset names to Yahoo Finance symbols
const ASSET_MAP: Record<string, string> = {
  'EUR/USD': 'EURUSD=X',
  'GBP/USD': 'GBPUSD=X',
  'USD/JPY': 'USDJPY=X',
  'AUD/USD': 'AUDUSD=X',
  'USD/CAD': 'USDCAD=X',
  'USD/CHF': 'USDCHF=X',
  'EUR/JPY': 'EURJPY=X',
  'GBP/JPY': 'GBPJPY=X',
  'EUR/GBP': 'EURGBP=X',
  'NZD/USD': 'NZDUSD=X',
  'BTC/USD': 'BTC-USD',
  'ETH/USD': 'ETH-USD',
  'GOLD': 'GC=F',
  'OIL': 'CL=F',
  // OTC Assets (use closest equivalent live feed)
  'EUR/USD OTC': 'EURUSD=X',
  'GBP/USD OTC': 'GBPUSD=X',
  'USD/JPY OTC': 'USDJPY=X',
  'AUD/USD OTC': 'AUDUSD=X',
};

export const SUPPORTED_ASSETS = Object.keys(ASSET_MAP);

// How far back to fetch based on timeframe (to ensure 100+ valid candles)
const LOOKBACK_DAYS: Record<string, number> = {
  '1m': 5,
  '5m': 14,
  '15m': 30,
  '1h': 90,
};

export async function fetchCandles(asset: string, timeframe: string = '5m'): Promise<MarketCandle[]> {
  const symbol = ASSET_MAP[asset] || ASSET_MAP['EUR/USD'];
  const intervalMap: Record<string, '1m' | '5m' | '15m' | '1h'> = {
    '1m': '1m',
    '5m': '5m',
    '15m': '15m',
    '1h': '1h',
  };
  const interval = intervalMap[timeframe] || '5m';
  const daysBack = LOOKBACK_DAYS[timeframe] || 14;
  const period1 = new Date(Date.now() - daysBack * 24 * 60 * 60 * 1000);

  try {
    const result = await yahooFinance.chart(symbol, {
      interval,
      period1,
    } as any);

    if (!result.quotes || result.quotes.length === 0) {
      throw new Error(`No data returned for ${asset}.`);
    }

    // Filter out candles with null OHLC values (market closed periods)
    const candles: MarketCandle[] = result.quotes
      .filter((q: any) => q.open != null && q.close != null && q.high != null && q.low != null)
      .map((q: any) => ({
        time: new Date(q.date).getTime(),
        open: q.open,
        high: q.high,
        low: q.low,
        close: q.close,
        volume: q.volume ?? 0,
      }));

    if (candles.length < 30) {
      throw new Error(
        `Insufficient data for ${asset}. Only ${candles.length} valid candles found — market may be closed.`
      );
    }

    console.log(`[MarketData] Fetched ${candles.length} valid candles for ${asset} (${timeframe})`);
    return candles;
  } catch (err: any) {
    console.error(`[MarketData] Error fetching ${asset} (${symbol}):`, err.message);
    throw new Error(
      err.message.includes('Insufficient') || err.message.includes('No data')
        ? err.message
        : `Could not fetch market data for ${asset}. Check your connection or try a different asset.`
    );
  }
}

export async function getCurrentPrice(asset: string): Promise<number> {
  const symbol = ASSET_MAP[asset] || ASSET_MAP['EUR/USD'];
  try {
    const quote = await yahooFinance.quote(symbol) as any;
    return quote.regularMarketPrice ?? 0;
  } catch {
    return 0;
  }
}
