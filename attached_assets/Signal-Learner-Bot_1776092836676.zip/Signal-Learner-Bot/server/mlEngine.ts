import { analyzeCandles } from './indicators';
import { fetchCandles } from './marketData';
import type { IndicatorSnapshot, IndicatorVote } from '@shared/schema';

export const INDICATOR_NAMES = ['rsi', 'macd', 'bollingerBands', 'emaCross', 'stochastic', 'priceAction'] as const;
export type IndicatorName = typeof INDICATOR_NAMES[number];

export type WeightMap = Record<IndicatorName, number>;

export type SignalDecision = {
  action: 'BUY' | 'SELL';
  confidence: number;
  price: number;
  indicators: IndicatorSnapshot;
};

/**
 * Signal decision using weighted majority voting.
 *
 * Steps:
 * 1. Collect non-NEUTRAL votes, weighted by indicator weight × indicator confidence
 * 2. Count how many indicators vote each direction (ignoring NEUTRAL)
 * 3. Direction wins only if it has MORE votes than the other direction (strict majority)
 * 4. Confidence = (winningWeightedScore / totalWeightedScore) × scaledRange
 *    This naturally captures how "one-sided" the vote is.
 * 5. Tie-break (equal vote count): pick the side with higher total weighted score.
 *    Confidence is capped low to signal uncertainty.
 */
export function computeSignal(
  indicators: IndicatorSnapshot,
  weights: WeightMap
): { action: 'BUY' | 'SELL'; confidence: number } {
  let buyWeightedScore  = 0;
  let sellWeightedScore = 0;
  let buyVoteCount  = 0;
  let sellVoteCount = 0;

  for (const name of INDICATOR_NAMES) {
    const vote: IndicatorVote = (indicators as any)[name];
    if (!vote || vote.direction === 'NEUTRAL') continue;

    const w = weights[name] ?? 1.0;
    const score = w * (vote.confidence / 100);

    if (vote.direction === 'BUY') {
      buyWeightedScore += score;
      buyVoteCount++;
    } else {
      sellWeightedScore += score;
      sellVoteCount++;
    }
  }

  const totalActive = buyVoteCount + sellVoteCount;

  // Not enough signal — default to a coin flip based on scores
  if (totalActive === 0) {
    return { action: 'BUY', confidence: 50 };
  }

  const totalScore = buyWeightedScore + sellWeightedScore;
  let action: 'BUY' | 'SELL';
  let winningScore: number;
  let winCount: number;
  let loseCount: number;

  if (buyVoteCount > sellVoteCount) {
    action = 'BUY';
    winningScore = buyWeightedScore;
    winCount  = buyVoteCount;
    loseCount = sellVoteCount;
  } else if (sellVoteCount > buyVoteCount) {
    action = 'SELL';
    winningScore = sellWeightedScore;
    winCount  = sellVoteCount;
    loseCount = buyVoteCount;
  } else {
    // Tie by count → use weighted score
    action = buyWeightedScore >= sellWeightedScore ? 'BUY' : 'SELL';
    winningScore = Math.max(buyWeightedScore, sellWeightedScore);
    winCount  = buyVoteCount;  // equal
    loseCount = sellVoteCount;
  }

  // Dominance factor: how one-sided is the vote? (0 = tie, 1 = all agree)
  const scoreDominance = totalScore > 0 ? winningScore / totalScore : 0.5;
  const voteDominance  = totalActive > 0 ? (winCount - loseCount) / totalActive : 0;

  // Blend both dominance metrics
  const rawStrength = scoreDominance * 0.6 + (0.5 + voteDominance * 0.5) * 0.4;

  // Scale to 52–97 range — reflects real uncertainty of markets
  const confidence = Math.round(Math.min(97, Math.max(52, 52 + rawStrength * 45)));

  return { action, confidence };
}

export async function generateSignal(
  asset: string,
  timeframe: string,
  weights: WeightMap
): Promise<SignalDecision> {
  const candles = await fetchCandles(asset, timeframe);
  const indicators = analyzeCandles(candles);
  const { action, confidence } = computeSignal(indicators, weights);
  const price = candles[candles.length - 1].close;
  return { action, confidence, price, indicators };
}

/** Adjust weights based on resolved signal outcome (the actual learning step). */
export function computeWeightUpdates(
  indicators: IndicatorSnapshot,
  finalAction: 'BUY' | 'SELL',
  result: 'WIN' | 'LOSS',
  currentWeights: WeightMap
): WeightMap {
  const updated = { ...currentWeights };

  for (const name of INDICATOR_NAMES) {
    const vote = (indicators as any)[name] as IndicatorVote | undefined;
    if (!vote || vote.direction === 'NEUTRAL') continue;

    const agreedWithSignal = vote.direction === finalAction;

    if (result === 'WIN') {
      updated[name] = agreedWithSignal
        ? Math.min(2.5, updated[name] + 0.10)   // correct → reward
        : Math.max(0.1, updated[name] - 0.05);  // wrong → mild penalty
    } else {
      updated[name] = agreedWithSignal
        ? Math.max(0.1, updated[name] - 0.08)   // agreed but lost → bigger penalty
        : Math.min(2.5, updated[name] + 0.04);  // disagreed and lost → slight reward
    }
  }

  return updated;
}

export function getDefaultWeights(): WeightMap {
  return {
    rsi:           1.0,
    macd:          1.0,
    bollingerBands: 1.0,
    emaCross:      1.0,
    stochastic:    1.0,
    priceAction:   1.0,
  };
}
