import type { MarketCandle, IndicatorVote, IndicatorSnapshot } from '@shared/schema';

// ─── Utility ────────────────────────────────────────────────────────────────

function avg(arr: number[]): number {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function stdDev(arr: number[]): number {
  const mean = avg(arr);
  return Math.sqrt(avg(arr.map(v => (v - mean) ** 2)));
}

function ema(values: number[], period: number): number[] {
  const k = 2 / (period + 1);
  const out: number[] = [values[0]];
  for (let i = 1; i < values.length; i++) {
    out.push(values[i] * k + out[i - 1] * (1 - k));
  }
  return out;
}

// ─── RSI (14) ────────────────────────────────────────────────────────────────
// Only signals at real extremes. Neutral zone 45–55.

export function calculateRSI(closes: number[], period = 14): number {
  if (closes.length < period + 1) return 50;
  const gains: number[] = [];
  const losses: number[] = [];
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    gains.push(diff > 0 ? diff : 0);
    losses.push(diff < 0 ? -diff : 0);
  }
  let avgGain = avg(gains);
  let avgLoss = avg(losses);
  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    avgGain = (avgGain * (period - 1) + (diff > 0 ? diff : 0)) / period;
    avgLoss = (avgLoss * (period - 1) + (diff < 0 ? -diff : 0)) / period;
  }
  if (avgLoss === 0) return 100;
  return 100 - 100 / (1 + avgGain / avgLoss);
}

export function rsiSignal(closes: number[]): IndicatorVote {
  const rsi = calculateRSI(closes);
  if (rsi < 20) return { direction: 'BUY',  value: rsi, confidence: 95 };
  if (rsi < 30) return { direction: 'BUY',  value: rsi, confidence: 88 };
  if (rsi < 38) return { direction: 'BUY',  value: rsi, confidence: 70 };
  if (rsi > 80) return { direction: 'SELL', value: rsi, confidence: 95 };
  if (rsi > 70) return { direction: 'SELL', value: rsi, confidence: 88 };
  if (rsi > 62) return { direction: 'SELL', value: rsi, confidence: 70 };
  // 38–62 is the neutral zone — no reliable signal
  return { direction: 'NEUTRAL', value: rsi, confidence: 0 };
}

// ─── Stochastic Oscillator (14, 3) ───────────────────────────────────────────
// Sensitive to short-term reversals, counteracts trend bias.

function stochasticK(highs: number[], lows: number[], closes: number[], period = 14): number[] {
  const result: number[] = [];
  for (let i = period - 1; i < closes.length; i++) {
    const hiSlice = highs.slice(i - period + 1, i + 1);
    const loSlice = lows.slice(i - period + 1, i + 1);
    const hh = Math.max(...hiSlice);
    const ll = Math.min(...loSlice);
    result.push(hh === ll ? 50 : ((closes[i] - ll) / (hh - ll)) * 100);
  }
  return result;
}

export function stochasticSignal(candles: MarketCandle[]): IndicatorVote {
  if (candles.length < 20) return { direction: 'NEUTRAL', value: 50, confidence: 0 };
  const highs  = candles.map(c => c.high);
  const lows   = candles.map(c => c.low);
  const closes = candles.map(c => c.close);
  const kLine  = stochasticK(highs, lows, closes, 14);
  // Smooth to %D with SMA-3
  const dLine: number[] = [];
  for (let i = 2; i < kLine.length; i++) {
    dLine.push((kLine[i] + kLine[i - 1] + kLine[i - 2]) / 3);
  }
  if (dLine.length === 0) return { direction: 'NEUTRAL', value: 50, confidence: 0 };
  const d = dLine[dLine.length - 1];
  const prevD = dLine[dLine.length - 2] ?? d;
  // Strong oversold / overbought
  if (d < 15 && d > prevD)  return { direction: 'BUY',  value: d, confidence: 92 };
  if (d < 20)               return { direction: 'BUY',  value: d, confidence: 82 };
  if (d < 30)               return { direction: 'BUY',  value: d, confidence: 68 };
  if (d > 85 && d < prevD)  return { direction: 'SELL', value: d, confidence: 92 };
  if (d > 80)               return { direction: 'SELL', value: d, confidence: 82 };
  if (d > 70)               return { direction: 'SELL', value: d, confidence: 68 };
  return { direction: 'NEUTRAL', value: d, confidence: 0 };
}

// ─── MACD (12, 26, 9) ────────────────────────────────────────────────────────
// Signal only on actual crossovers. Mid-trend hints are discarded.

export function macdSignal(closes: number[]): IndicatorVote {
  if (closes.length < 40) return { direction: 'NEUTRAL', value: 0, confidence: 0 };
  const ema12 = ema(closes, 12);
  const ema26 = ema(closes, 26);
  const macdLine  = ema12.map((v, i) => v - ema26[i]);
  const signalLineRaw = ema(macdLine.slice(-18), 9);
  const lastMACD  = macdLine[macdLine.length - 1];
  const prevMACD  = macdLine[macdLine.length - 2];
  const lastSig   = signalLineRaw[signalLineRaw.length - 1];
  const prevSig   = signalLineRaw[signalLineRaw.length - 2] ?? lastSig;
  const hist      = lastMACD - lastSig;
  const prevHist  = prevMACD - (prevSig ?? lastSig);

  // Bullish crossover (MACD crosses above signal from below)
  if (prevHist <= 0 && hist > 0) return { direction: 'BUY',  value: hist, confidence: 88 };
  // Bearish crossover
  if (prevHist >= 0 && hist < 0) return { direction: 'SELL', value: hist, confidence: 88 };

  // Histogram accelerating in direction (momentum building)
  const histAcc = hist - prevHist;
  if (hist > 0 && histAcc > 0) return { direction: 'BUY',  value: hist, confidence: 60 };
  if (hist < 0 && histAcc < 0) return { direction: 'SELL', value: hist, confidence: 60 };

  // Histogram decelerating (possible reversal coming)
  if (hist > 0 && histAcc < 0 && histAcc / (Math.abs(hist) + 1e-10) < -0.3)
    return { direction: 'SELL', value: hist, confidence: 55 };
  if (hist < 0 && histAcc > 0 && histAcc / (Math.abs(hist) + 1e-10) > 0.3)
    return { direction: 'BUY',  value: hist, confidence: 55 };

  return { direction: 'NEUTRAL', value: hist, confidence: 0 };
}

// ─── Bollinger Bands (20, 2) ─────────────────────────────────────────────────
// Split the band into 5 zones — no NEUTRAL dead zone.

export function bollingerBandsSignal(closes: number[]): IndicatorVote {
  if (closes.length < 20) return { direction: 'NEUTRAL', value: 0.5, confidence: 0 };
  const last20 = closes.slice(-20);
  const mid    = avg(last20);
  const sd     = stdDev(last20);
  const upper  = mid + 2 * sd;
  const lower  = mid - 2 * sd;
  const price  = closes[closes.length - 1];
  const bPct   = sd === 0 ? 0.5 : (price - lower) / (upper - lower);

  // Outside/at bands
  if (bPct <= 0.00) return { direction: 'BUY',  value: bPct, confidence: 95 };
  if (bPct <= 0.15) return { direction: 'BUY',  value: bPct, confidence: 88 };
  if (bPct <= 0.30) return { direction: 'BUY',  value: bPct, confidence: 72 };
  if (bPct <= 0.45) return { direction: 'BUY',  value: bPct, confidence: 58 };
  // Upper half
  if (bPct >= 1.00) return { direction: 'SELL', value: bPct, confidence: 95 };
  if (bPct >= 0.85) return { direction: 'SELL', value: bPct, confidence: 88 };
  if (bPct >= 0.70) return { direction: 'SELL', value: bPct, confidence: 72 };
  if (bPct >= 0.55) return { direction: 'SELL', value: bPct, confidence: 58 };
  // Dead center (0.45–0.55) truly neutral
  return { direction: 'NEUTRAL', value: bPct, confidence: 0 };
}

// ─── EMA Crossover (9, 21) ───────────────────────────────────────────────────
// More sensitive — responds to cross AND slope change.

export function emaCrossSignal(closes: number[]): IndicatorVote {
  if (closes.length < 25) return { direction: 'NEUTRAL', value: 0, confidence: 0 };
  const fast = ema(closes, 9);
  const slow = ema(closes, 21);
  const diff     = fast[fast.length - 1] - slow[slow.length - 1];
  const prevDiff = fast[fast.length - 2] - slow[slow.length - 2];
  const prevPrevDiff = fast[fast.length - 3] - slow[slow.length - 3];

  // Golden / Death cross (most reliable)
  if (prevDiff <= 0 && diff > 0) return { direction: 'BUY',  value: diff, confidence: 90 };
  if (prevDiff >= 0 && diff < 0) return { direction: 'SELL', value: diff, confidence: 90 };

  // Slope of divergence
  const diffAccel = (diff - prevDiff) - (prevDiff - prevPrevDiff);
  const pct = Math.abs(diff / (slow[slow.length - 1] + 1e-10)) * 100;
  const conf = Math.min(80, 50 + pct * 3);

  if (diff > 0) {
    // Already above: if gap is shrinking fast → possible reversal to SELL
    if (diffAccel < -pct * 0.3) return { direction: 'SELL', value: diff, confidence: 62 };
    return { direction: 'BUY', value: diff, confidence: conf };
  }
  if (diff < 0) {
    if (diffAccel > pct * 0.3) return { direction: 'BUY', value: diff, confidence: 62 };
    return { direction: 'SELL', value: diff, confidence: conf };
  }
  return { direction: 'NEUTRAL', value: 0, confidence: 0 };
}

// ─── Price Action Momentum (last 6 candles) ───────────────────────────────────
// Captures micro-trend and reversal patterns independently of lagging indicators.

export function priceActionSignal(candles: MarketCandle[]): IndicatorVote {
  if (candles.length < 10) return { direction: 'NEUTRAL', value: 0, confidence: 0 };
  const recent = candles.slice(-6);
  const last   = recent[recent.length - 1];

  // Body sizes
  const bodies   = recent.map(c => Math.abs(c.close - c.open));
  const avgBody  = avg(bodies);
  const lastBody = bodies[bodies.length - 1];
  const prevBody = bodies[bodies.length - 2];

  // Count bullish vs bearish candles
  const bulls = recent.filter(c => c.close > c.open).length;
  const bears = recent.filter(c => c.close <= c.open).length;

  // Engulfing pattern (most reliable reversal signal for binary options)
  const prevC = candles[candles.length - 2];
  const currC = candles[candles.length - 1];
  const bullishEngulfing =
    prevC.close < prevC.open &&  // previous bearish
    currC.close > currC.open &&  // current bullish
    currC.open  < prevC.close && // opens below prev close
    currC.close > prevC.open;   // closes above prev open
  const bearishEngulfing =
    prevC.close > prevC.open &&
    currC.close < currC.open &&
    currC.open  > prevC.close &&
    currC.close < prevC.open;

  if (bullishEngulfing && lastBody > avgBody * 1.3)
    return { direction: 'BUY',  value: lastBody / avgBody, confidence: 90 };
  if (bearishEngulfing && lastBody > avgBody * 1.3)
    return { direction: 'SELL', value: lastBody / avgBody, confidence: 90 };

  // Hammer / Shooting Star (at extreme lows/highs)
  const range     = last.high - last.low;
  const lowerWick = Math.min(last.open, last.close) - last.low;
  const upperWick = last.high - Math.max(last.open, last.close);
  if (range > 0) {
    const lowerPct = lowerWick / range;
    const upperPct = upperWick / range;
    if (lowerPct > 0.6 && lastBody / range < 0.3)
      return { direction: 'BUY',  value: lowerPct, confidence: 78 };
    if (upperPct > 0.6 && lastBody / range < 0.3)
      return { direction: 'SELL', value: upperPct, confidence: 78 };
  }

  // General momentum: majority of recent candles
  if (bulls >= 5) return { direction: 'BUY',  value: bulls / 6, confidence: 65 };
  if (bears >= 5) return { direction: 'SELL', value: bears / 6, confidence: 65 };
  if (bulls === 4) return { direction: 'BUY',  value: 4 / 6, confidence: 55 };
  if (bears === 4) return { direction: 'SELL', value: 4 / 6, confidence: 55 };

  return { direction: 'NEUTRAL', value: 0.5, confidence: 0 };
}

// ─── Composite ───────────────────────────────────────────────────────────────

export function analyzeCandles(candles: MarketCandle[]): IndicatorSnapshot {
  const closes = candles.map(c => c.close);
  return {
    rsi:           rsiSignal(closes),
    macd:          macdSignal(closes),
    bollingerBands: bollingerBandsSignal(closes),
    emaCross:      emaCrossSignal(closes),
    stochastic:    stochasticSignal(candles),
    priceAction:   priceActionSignal(candles),
  };
}
