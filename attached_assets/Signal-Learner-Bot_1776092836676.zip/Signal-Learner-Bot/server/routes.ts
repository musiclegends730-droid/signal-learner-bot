import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { generateSignal, computeWeightUpdates, INDICATOR_NAMES } from "./mlEngine";
import { SUPPORTED_ASSETS } from "./marketData";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Initialize indicator weights on startup
  await storage.initWeightsIfNeeded();

  // GET /api/signals — list all signals
  app.get(api.signals.list.path, async (req, res) => {
    const signals = await storage.getSignals();
    res.json(signals);
  });

  // GET /api/signals/stats
  app.get(api.signals.stats.path, async (req, res) => {
    const stats = await storage.getStats();
    res.json(stats);
  });

  // GET /api/assets — list supported assets
  app.get('/api/assets', (req, res) => {
    res.json(SUPPORTED_ASSETS);
  });

  // POST /api/signals/generate — fetch real data and generate signal
  app.post(api.signals.generate.path, async (req, res) => {
    try {
      const input = api.signals.generate.input.parse(req.body);
      const weights = await storage.getWeights();
      
      const decision = await generateSignal(input.asset, input.timeframe || '5m', weights);

      const signal = await storage.createSignal({
        asset: input.asset,
        action: decision.action,
        price: decision.price.toFixed(5),
        confidence: decision.confidence,
        result: 'PENDING',
        indicators: decision.indicators as any,
        timeframe: input.timeframe || '5m',
      });

      res.status(201).json(signal);
    } catch (err: any) {
      console.error('[GenerateSignal] Error:', err.message);
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      return res.status(500).json({ message: err.message || 'Failed to generate signal' });
    }
  });

  // PATCH /api/signals/:id/result — mark win/loss + update weights
  app.patch(api.signals.updateResult.path, async (req, res) => {
    try {
      const input = api.signals.updateResult.input.parse(req.body);
      const signal = await storage.getSignal(Number(req.params.id));
      if (!signal) {
        return res.status(404).json({ message: 'Signal not found' });
      }

      const updatedSignal = await storage.updateSignalResult(Number(req.params.id), input.result);

      // Update indicator weights based on outcome (the ML learning step)
      if (signal.indicators) {
        const currentWeights = await storage.getWeights();
        const newWeights = computeWeightUpdates(
          signal.indicators as any,
          signal.action as 'BUY' | 'SELL',
          input.result,
          currentWeights
        );
        await storage.updateWeights(newWeights);
        console.log(`[ML] Updated weights after ${input.result} on ${signal.asset}:`, newWeights);
      }

      res.json(updatedSignal);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  return httpServer;
}
