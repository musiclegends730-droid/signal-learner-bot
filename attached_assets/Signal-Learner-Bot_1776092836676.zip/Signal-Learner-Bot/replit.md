# QuantumTrade AI — Pocket Option Signal Bot

## Overview
A binary options signal generator that uses **real live market data** from Yahoo Finance, calculates technical indicators, and generates BUY/SELL signals. It learns from win/loss outcomes by adjusting indicator weights.

## Architecture

### Backend (`server/`)
- `server/index.ts` — Express app entry point
- `server/routes.ts` — API route handlers
- `server/storage.ts` — PostgreSQL storage layer (signals + indicator weights)
- `server/db.ts` — Drizzle ORM database connection
- `server/marketData.ts` — Yahoo Finance data fetching (yahoo-finance2 v3)
- `server/indicators.ts` — Technical analysis: RSI, MACD, Bollinger Bands, EMA Cross
- `server/mlEngine.ts` — Signal generation + ML weight update logic

### Frontend (`client/src/`)
- `pages/Dashboard.tsx` — Main dashboard page
- `components/StatsGrid.tsx` — Win rate, confidence, indicator weights display
- `components/SignalsList.tsx` — Signal feed with indicator breakdown per signal
- `components/CreateSignalDialog.tsx` — Asset selection + signal generation UI
- `hooks/use-signals.ts` — React Query hooks for all API calls

### Shared (`shared/`)
- `schema.ts` — Drizzle schema: `signals` table + `indicator_weights` table
- `routes.ts` — API contract types

## How It Works

1. **Signal Generation**: User selects asset + timeframe → backend fetches 2 weeks of real OHLCV data → calculates RSI(14), MACD(12,26,9), Bollinger Bands(20,2), EMA Cross(9,21) → weighted voting determines BUY/SELL → confidence score derived from indicator agreement

2. **ML Learning**: Each indicator's vote is stored with the signal. When user marks WIN/LOSS:
   - Correct indicators → weight += 0.08
   - Wrong indicators → weight -= 0.04
   - Weights range: 0.1 to 2.5

3. **Confidence**: Weighted sum of agreeing indicators / total weight, scaled to 50-99%

## Supported Assets (18 total)
Pocket Option forex pairs (EUR/USD, GBP/USD, USD/JPY, etc.), crypto (BTC/USD, ETH/USD), GOLD, OIL, and OTC variants.

## Key Dependencies
- `yahoo-finance2` — Real market data (v3 API: instantiate with `new YahooFinance()`)
- `drizzle-orm` + `pg` — PostgreSQL ORM
- `@tanstack/react-query` — Data fetching
- `framer-motion` — Animations
- `recharts` — Charts
- `shadcn/ui` components

## Database Tables
- `signals` — All generated signals with indicator snapshots (jsonb)
- `indicator_weights` — Learned weights for RSI, MACD, bollingerBands, emaCross

## Running
```bash
npm run dev   # starts Express + Vite on port 5000
npm run db:push  # sync schema changes
```
