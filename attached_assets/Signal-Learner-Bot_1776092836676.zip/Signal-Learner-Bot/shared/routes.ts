import { z } from 'zod';
import { signals, indicatorWeights } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  signals: {
    list: {
      method: 'GET' as const,
      path: '/api/signals' as const,
      responses: {
        200: z.array(z.custom<typeof signals.$inferSelect>()),
      },
    },
    generate: {
      method: 'POST' as const,
      path: '/api/signals/generate' as const,
      input: z.object({
        asset: z.string(),
        timeframe: z.string().optional().default('5m'),
      }),
      responses: {
        201: z.custom<typeof signals.$inferSelect>(),
        400: errorSchemas.validation,
        500: errorSchemas.internal,
      },
    },
    updateResult: {
      method: 'PATCH' as const,
      path: '/api/signals/:id/result' as const,
      input: z.object({
        result: z.enum(['WIN', 'LOSS']),
      }),
      responses: {
        200: z.custom<typeof signals.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    stats: {
      method: 'GET' as const,
      path: '/api/signals/stats' as const,
      responses: {
        200: z.object({
          totalSignals: z.number(),
          wins: z.number(),
          losses: z.number(),
          winRate: z.number(),
          currentConfidence: z.number(),
          indicatorWeights: z.array(z.custom<typeof indicatorWeights.$inferSelect>()),
        }),
      },
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type SignalResponse = typeof signals.$inferSelect;
export type SignalsListResponse = (typeof signals.$inferSelect)[];
export type StatsResponse = {
  totalSignals: number;
  wins: number;
  losses: number;
  winRate: number;
  currentConfidence: number;
  indicatorWeights: (typeof indicatorWeights.$inferSelect)[];
};
export type UpdateSignalResultInput = z.infer<typeof api.signals.updateResult.input>;
export type GenerateSignalInput = z.infer<typeof api.signals.generate.input>;
