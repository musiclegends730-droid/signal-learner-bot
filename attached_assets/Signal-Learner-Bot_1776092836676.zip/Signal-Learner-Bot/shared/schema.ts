import { pgTable, text, serial, integer, numeric, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const signals = pgTable("signals", {
  id: serial("id").primaryKey(),
  asset: text("asset").notNull(),
  action: text("action").notNull(),
  price: numeric("price").notNull(),
  confidence: integer("confidence").notNull(),
  result: text("result").notNull().default('PENDING'),
  indicators: jsonb("indicators"),
  timeframe: text("timeframe").default("5m"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const indicatorWeights = pgTable("indicator_weights", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  weight: numeric("weight").notNull().default("1.0"),
  correctPredictions: integer("correct_predictions").notNull().default(0),
  totalPredictions: integer("total_predictions").notNull().default(0),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertSignalSchema = createInsertSchema(signals).omit({
  id: true,
  createdAt: true,
});

export const insertIndicatorWeightSchema = createInsertSchema(indicatorWeights).omit({
  id: true,
  updatedAt: true,
});

export type Signal = typeof signals.$inferSelect;
export type InsertSignal = z.infer<typeof insertSignalSchema>;
export type IndicatorWeight = typeof indicatorWeights.$inferSelect;

export type IndicatorVote = {
  direction: 'BUY' | 'SELL' | 'NEUTRAL';
  value: number;
  confidence: number;
};

export type IndicatorSnapshot = {
  rsi: IndicatorVote;
  macd: IndicatorVote;
  bollingerBands: IndicatorVote;
  emaCross: IndicatorVote;
  stochastic: IndicatorVote;
  priceAction: IndicatorVote;
};

export type StatsResponse = {
  totalSignals: number;
  wins: number;
  losses: number;
  winRate: number;
  currentConfidence: number;
  indicatorWeights: IndicatorWeight[];
};

export type GenerateSignalRequest = {
  asset: string;
  timeframe?: string;
};

export type MarketCandle = {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};
